import sys


class Predictor:
    def setup(self):
        sys.exit(1)

    def predict(self):
        print("did predict")
